package main

func main() {

	unBufferedChan := make(chan int) // cant hold data

	// bufferedChan := make(chan int, 5) // can hold 5 integers

}
