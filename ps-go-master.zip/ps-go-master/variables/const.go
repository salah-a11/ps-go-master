package main

import "fmt"

func main() {
	// const are immutable
	const PI = 3.14
	fmt.Println("PI is", PI)

}
